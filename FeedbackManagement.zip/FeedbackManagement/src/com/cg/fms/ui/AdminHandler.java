package com.cg.fms.ui;

import com.cg.fms.dto.Employee;

public class AdminHandler {
	
	Employee admin;
	
	public AdminHandler(Employee employee) {
		super();
		admin = employee;
	}

	public void start(){
		System.out.println("Welcome " + admin.getEmployeeName());
		System.out.println("What do you want to do");
		
		//all menu items, switch case 
		
	}
	
}
